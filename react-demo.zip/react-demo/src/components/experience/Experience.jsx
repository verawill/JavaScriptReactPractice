import React from 'react'
import './experience.css'

const Experience = () => {
  return (
    <section id='experiences'>
    <h2>My Experience</h2>
    </section>
  )
}

export default Experience