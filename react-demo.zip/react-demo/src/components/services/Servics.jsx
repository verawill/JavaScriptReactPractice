import React from 'react'
import './services.css'

const Servics = () => {
  return (
    <section id='services'>Services</section>
  )
}

export default Servics